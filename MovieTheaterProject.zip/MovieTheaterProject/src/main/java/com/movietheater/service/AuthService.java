package com.movietheater.service;

import com.movietheater.dto.AuthResponse;
import com.movietheater.dto.LoginRequest;
import com.movietheater.dto.RegisterRequest;
import com.movietheater.model.User;
import com.movietheater.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // REGISTER NEW USER
    public AuthResponse register(RegisterRequest request) {

        // Validate input fields
        if (request.getUsername() == null || request.getUsername().isBlank()) {
            return new AuthResponse(false,
                    "Username cannot be empty",
                    null, null, null, null);
        }

        if (request.getPassword() == null || request.getPassword().length() < 6) {
            return new AuthResponse(false,
                    "Password must contain at least 6 characters",
                    null, null, null, null);
        }

        // Check if username already exists
        if (userRepository.existsByUsername(request.getUsername())) {
            return new AuthResponse(false,
                    "Username already exists",
                    null, null, null, null);
        }

        // Check if email already exists
        if (userRepository.existsByEmail(request.getEmail())) {
            return new AuthResponse(false,
                    "Email already exists",
                    null, null, null, null);
        }

        User user = new User(
                request.getFullName(),
                request.getUsername(),
                request.getEmail(),
                request.getPassword(),
                "CUSTOMER"
        );

        User savedUser = userRepository.save(user);

        return new AuthResponse(
                true,
                "Account created successfully",
                savedUser.getId(),
                savedUser.getFullName(),
                savedUser.getEmail(),
                savedUser.getRole()
        );
    }

    // LOGIN USER
    public AuthResponse login(LoginRequest request) {

        User user = userRepository.findByUsername(request.getUsername());

        // Invalid username
        if (user == null) {
            return new AuthResponse(false,
                    "Invalid username",
                    null, null, null, null);
        }

        // Invalid password
        if (!user.getPassword().equals(request.getPassword())) {
            return new AuthResponse(false,
                    "Invalid password",
                    null, null, null, null);
        }

        return new AuthResponse(
                true,
                "Login successful",
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getRole()
        );
    }
}